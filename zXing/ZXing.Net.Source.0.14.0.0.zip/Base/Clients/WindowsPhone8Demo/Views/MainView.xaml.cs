﻿using Microsoft.Phone.Controls;

namespace WindowsPhone8Demo.Views
{
    public partial class MainView : PhoneApplicationPage
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}