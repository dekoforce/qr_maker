﻿namespace BigIntegerLibrary
{

    /// <summary>
    /// The number's sign, where Positive also stands for the number zero.
    /// </summary>
    enum Sign { Positive, Negative };

}
