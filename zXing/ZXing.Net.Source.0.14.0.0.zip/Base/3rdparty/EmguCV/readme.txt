EmguCV binaries version libemgucv-windows-x64-2.4.0.1717

Only binaries for compilation of the demo application are added.

If you want to execute the demo you need the full package and you have to copy all the assemblies
and native libs from the official release to the destination directory of the demo project!